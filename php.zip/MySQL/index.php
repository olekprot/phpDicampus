<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Base de datos</h1>

    <ul>
        <li><a href="crearDB.php">Crear DB</a></li>
        <li><a href="crearTablaDB.php">Crear Tabla en DB</a></li>
        <li><a href="insertarDatos.php">Insertar datos</a></li>
        <li><a href=""></a></li>
        <li><a href=""></a></li>
    </ul>
   
</body>
</html>