<? $titulo ="😴 Bienvenidos";
   $descApt="Toy en la pagina de incio";
?>

<?php require 'includes/config.php'?> 
<?php include 'includes/header.php'?>
<!-- aquí el contenido -->
    <h2>Disfruta de la Astronomía como nunca lo has hecho</h2>
    <p> Lorem ipsum dolor sit amet consectetur adipisicing elit. Similique repellendus iste molestiae? Nihil consequuntur ratione obcaecati, laboriosam sunt enim asperiores rerum quaerat nam fugit debitis nobis suscipit laborum quos. Modi?</p>

    

<?php include 'includes/footer.php'?> 