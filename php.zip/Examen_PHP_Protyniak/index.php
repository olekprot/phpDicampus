
<?php include 'components/_header.php';?>
	
<?php include 'cards.php'?>

<?php include 'components/_footer.php';?>