<?php require 'components/_config.php';?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="icon" type="image/x-icon" href="favicon.png">
    <link rel="stylesheet" href="datos/style.css">
</head>
<body>
    <header>
        <nav>
            <ul>
                <li><a href="index.php">Inicio</a></li>
                <li><a href="newFilm.php">Nueva pelicula</a></li>
                <li><a href="https://github.com/olekprot/-Moving_Examen_PHP_Protyniak" target="_blank">GIT</a></li>
            </ul>
        </nav>
    </header>
    <main>
        