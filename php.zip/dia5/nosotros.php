<? $titulo ="Tienes somos";
$descApt="Somos un grupo de frikys de las estrellas";?>


<?php require 'includes/config.php'?> 
<?php include 'includes/header.php'?>
<!-- aquí el contenido -->
    <h2>Un grupo de Astrónomos aficionados</h2>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Est nobis ratione assumenda modi, optio facilis odio nemo aspernatur sunt magnam, ea laboriosam! Earum architecto cumque velit facere maxime cum nostrum.</p>

<?php include 'includes/footer.php'?> 