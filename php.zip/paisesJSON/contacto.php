<?php $t='Contacto';?>
<?php require 'component/config.php'; ?>
<?php include_once 'component/header.php'; ?>
<address>una pijada</address>
<?php include_once 'component/footer.php'; ?>