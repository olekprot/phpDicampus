<?php 
    $dates = [
        'name'=> 'Tom',
        'age' => 20,
        'gender' => 'male',
        'hobby' => 'football',
        'address' => 'Tokyo'
    ];
    $politicas = [
        'Politica de cookies' => 'https://google.com',
        'Politica de privacidad' => 'https://google.com',   
        'Terminos y condiciones' => 'https://google.com',
        'Contacto' => '#contacto'
    ];
?>