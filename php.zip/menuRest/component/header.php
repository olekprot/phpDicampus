<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><? echo($titulo)?></title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

 <header>
    <div class="logo">Restaurante</div>
    <nav>
        <ul>
            <li><a href="menu.php">Carta</a></li>
            <li><a href="admin.php">Admin</a></li>
        </ul>
    </nav>
</header>  

<main></main>