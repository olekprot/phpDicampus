<? $titulo ="Contacta con las Estrellas"?>


<?php require 'includes/config.php'?> 
<?php include 'includes/header.php'?>
<!-- aquí el contenido -->
    <h2>Contacto</h2>
    <p>Contacta con nosotros para ver las estrellas</p>

<?php include 'includes/footer.php'?> 