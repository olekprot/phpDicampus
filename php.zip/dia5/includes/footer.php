
    <h3><? echo $titulo?></h3>


    <p>trasteando con el código</p>
</main>
<footer>
    <? constructorFooter($footerMenu);?>
</footer>