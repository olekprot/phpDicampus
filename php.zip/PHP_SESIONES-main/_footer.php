</main>

<footer>
<p>Soy el Footer</p>
</footer>
</body>
</html>