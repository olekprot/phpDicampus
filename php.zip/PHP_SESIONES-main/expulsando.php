<?php require '_config.php';?>
<?php include '_header.php';?>

<h3>expulsando</h3>
<?php include '_footer.php';?>