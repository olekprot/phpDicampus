<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sesiones</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
    <nav>
        <ul>
            <li>
                <a href="index.php">inicio</a>
            </li>
            <li>
                <a href="cerrar.php">Cerrar Sesión</a>
            </li>
            <li>
                <a href="login.php">Acceder</a>
            </li>
            <li>
                <a href="panelSecreto.php">Ver Panel Admin</a>
            </li>
        </ul>
    </nav>
</header>
<main>
    
