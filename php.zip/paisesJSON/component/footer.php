
        </main>   
        <footer>
            <p>&copy; <?php echo date('Y');?> Paises</p>
        </footer>
        <script src="script.js"></script>
    </body>
</html>